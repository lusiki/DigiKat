Spirituality-related associations: full-period exploratory media landscape
Study period: 1 January 2021 to 10 September 2026 (2026 partial).
Source: 42,267,474 records in the supplied read-only merged DetermDB snapshot.

This supplement contains aggregate tables, methods/provenance diagnostics and
ten scientific figures in PNG and SVG. The PDF report is delivered separately.
Candidate records and pairs are unresolved name-search observations, not verified
editorial coverage. No human frame, stance or precision estimates are supplied.

Start with annual_landscape.csv, summary.json, county_landscape.csv,
platform_landscape.csv and sensitivity.csv. monthly_landscape.csv preserves
date/platform scope; common_domain_panel.csv provides a common-source sensitivity.
Rates use raw candidate records / raw monitored records within the same scope.
The measured collection regime changes in January 2024.

Model topic shares are exploratory assignments, not coded frame prevalence.
See topic_model_runs.csv, topic_terms.csv, topic_shares.csv and topic_audit.json.
Human review remains uncompleted. The blank review-queue design is preparation only.

Reproduction scripts and detailed definitions are in the repository under
studies/spirituality-associations/media/. The private directory and all 1,325
organisation rows are retained locally under output/private/media/v1/ and are
intentionally excluded from this aggregate bundle. No article URLs, vendor text,
titles, item identifiers or personal contact information are included here.
